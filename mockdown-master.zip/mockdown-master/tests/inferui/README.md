# InferUI Tests

This directory contains some tests for cases where we were observing weirdness on the InferUI benchmarks.
