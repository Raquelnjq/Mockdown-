from .scraper import Scraper

__all__ = [
    Scraper
]