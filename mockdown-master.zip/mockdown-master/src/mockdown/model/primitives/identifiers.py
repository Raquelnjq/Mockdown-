from __future__ import annotations

# For now, this is just a string.
ViewName = str
