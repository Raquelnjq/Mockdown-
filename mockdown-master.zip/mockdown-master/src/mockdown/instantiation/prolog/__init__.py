from mockdown.instantiation.prolog.instantiator import PrologConstraintInstantiator

__all__ = [
    'PrologConstraintInstantiator'
]
