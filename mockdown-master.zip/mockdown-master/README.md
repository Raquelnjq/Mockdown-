# Mockdown

This is the whole mockdown pipeline in Python.

## Installation

To run Mockdown, run the following commands from a shell at the root directory:
> pipenv install
> pipenv shell
> python3 setup.py develop
> mockdown serve