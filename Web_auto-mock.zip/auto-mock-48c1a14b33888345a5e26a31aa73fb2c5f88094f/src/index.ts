import {main} from './NodeBench'

export default main;

main().then(console.log).catch(console.log);
