import { main } from './InferUIBench'

main().then(console.log).catch(console.log);