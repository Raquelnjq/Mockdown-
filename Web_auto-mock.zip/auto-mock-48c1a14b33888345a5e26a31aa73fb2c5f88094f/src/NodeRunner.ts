import { main } from './NodeBench'

main().then(console.log).catch(console.log);