import { runHierBench, calcHierStats } from './NodeBench'
 
runHierBench().then(console.log).catch(console.log);
// calcHierStats().then(console.log).catch(console.log);