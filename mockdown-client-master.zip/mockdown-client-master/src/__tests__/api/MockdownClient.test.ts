import { MockdownClient } from '../../api';

describe(MockdownClient, () => {
   test(`write more tests.`, () => {
       expect(1).toBe(1);
   });
});
