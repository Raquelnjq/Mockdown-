import { ILayoutViewTree } from '../..';

// describe(ILayoutViewTree.POJO, () => {
//
// });
