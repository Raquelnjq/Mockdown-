export interface IIdentifiable<I> {
    readonly id: I;
}